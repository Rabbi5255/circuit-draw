1. Android Studio (Koala ba notun) install korun.
2. File > Open > CircuitDraw folder select korun. Gradle sync hoye jabe (internet lagbe).
3. Phone USB debugging on kore Run (▶) chapun, athoba Build > Build APK(s).
4. Play Store er jonno: Build > Generate Signed Bundle (AAB).
App er UI: app/src/main/assets/index.html (ekhane edit korle app e change hoy).
